
import React from 'react'

export default function App(){
  return (
    <div className="min-h-screen grid place-items-center p-10">
      <div className="max-w-2xl rounded-2xl border bg-background p-8 shadow-sm">
        <h1 className="text-2xl font-semibold mb-2">Готово для StackBlitz</h1>
        <p className="text-sm text-muted-foreground">
          Этот проект настроен (Vite + React + TS + Tailwind). Открой <code>src/App.tsx</code> и вставь свой компонент PartnerOffersShowcase.
        </p>
      </div>
    </div>
  )
}
